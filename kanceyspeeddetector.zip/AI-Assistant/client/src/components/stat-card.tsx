
import { motion } from "framer-motion";
import { ArrowDown, ArrowUp, Activity, Zap } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  unit: string;
  icon: "download" | "upload" | "ping" | "jitter";
  active?: boolean;
}

const icons = {
  download: ArrowDown,
  upload: ArrowUp,
  ping: Activity,
  jitter: Zap
};

export function StatCard({ label, value, unit, icon, active }: StatCardProps) {
  const Icon = icons[icon];
  
  return (
    <motion.div 
      className={`relative p-6 rounded-2xl border transition-all duration-300 glass-card overflow-hidden group
        ${active ? 'border-primary/40 bg-primary/8 shadow-[0_0_16px_rgba(255,193,7,0.12)]' : 'border-white/4 bg-white/3'}
      `}
      whileHover={{ scale: 1.02 }}
    >
      <div className="flex items-start justify-between mb-4">
        <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        <div className={`p-2 rounded-lg ${active ? 'bg-primary/20 text-primary' : 'bg-white/5 text-muted-foreground'}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      
      <div className="flex items-baseline gap-1">
        <span className="text-3xl font-bold font-heading tabular-nums tracking-tight text-foreground">
          {value}
        </span>
        <span className="text-sm font-medium text-muted-foreground">{unit}</span>
      </div>
      
      {/* Active Indicator Line */}
      {active && (
        <motion.div 
          layoutId="active-line"
          className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent"
        />
      )}
    </motion.div>
  );
}
