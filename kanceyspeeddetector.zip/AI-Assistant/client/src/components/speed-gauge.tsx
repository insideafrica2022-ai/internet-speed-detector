
import { motion } from "framer-motion";

interface SpeedGaugeProps {
  value: number;
  max: number;
  label: string;
  isActive: boolean;
}

export function SpeedGauge({ value, max, label, isActive }: SpeedGaugeProps) {
  // Normalize value to 0-100 range for stroke-dasharray
  const normalizedValue = Math.min((value / max) * 100, 100);
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (normalizedValue / 100) * circumference;

  return (
    <div className="relative flex flex-col items-center justify-center p-8">
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
          <circle
            cx="100"
            cy="100"
            r={radius}
            stroke="hsl(var(--muted))"
            strokeWidth="12"
            fill="transparent"
            className="opacity-20"
          />
          {/* Active Gradient Circle */}
          <motion.circle
            cx="100"
            cy="100"
            r={radius}
            stroke="hsl(var(--primary))"
            strokeWidth="12"
            fill="transparent"
            strokeDasharray={circumference}
            animate={{ strokeDashoffset }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            strokeLinecap="round"
            className={`drop-shadow-[0_0_10px_hsl(var(--primary))] ${isActive ? 'opacity-100' : 'opacity-30'}`}
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-black font-heading tracking-tighter tabular-nums"
          >
            {value.toFixed(1)}
          </motion.div>
          <div className="text-sm md:text-base font-medium text-muted-foreground uppercase tracking-widest mt-2">
            Mbps
          </div>
        </div>
      </div>
      
      <div className={`mt-4 text-lg font-medium transition-colors duration-300 ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
        {label}
      </div>
    </div>
  );
}
