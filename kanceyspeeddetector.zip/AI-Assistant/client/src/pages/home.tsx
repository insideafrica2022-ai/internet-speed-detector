
import { useState, useRef, useEffect } from "react";
import { SpeedTestEngine, type SpeedTestResult } from "@/lib/speed-test";
import { SpeedGauge } from "@/components/speed-gauge";
import { StatCard } from "@/components/stat-card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Play, RotateCcw, Share2, Wifi } from "lucide-react";
import bgImage from "@assets/generated_images/elegant_tech_minimal_background.png";

type TestPhase = 'idle' | 'ping' | 'download' | 'upload' | 'complete';

export default function Home() {
  const [phase, setPhase] = useState<TestPhase>('idle');
  const [progress, setProgress] = useState(0);
  const [currentSpeed, setCurrentSpeed] = useState(0);
  const [result, setResult] = useState<SpeedTestResult>({
    ping: 0,
    jitter: 0,
    download: 0,
    upload: 0,
    score: 0
  });

  const engineRef = useRef<SpeedTestEngine>(new SpeedTestEngine());

  const startTest = async () => {
    if (phase !== 'idle' && phase !== 'complete') return;
    
    setPhase('ping');
    setProgress(0);
    setCurrentSpeed(0);
    setResult({ ping: 0, jitter: 0, download: 0, upload: 0, score: 0 });

    try {
      const finalResult = await engineRef.current.run((p, prog, speed) => {
        setPhase(p as TestPhase);
        setProgress(prog);
        setCurrentSpeed(speed);
        
        // Update intermediate results for display
        if (p === 'ping') {
           // We don't get interim ping values easily from the engine in this simple version, 
           // but we could if we expanded the callback. 
           // For now, the engine sets the result at the END of the phase.
        }
      });
      setResult(finalResult);
    } catch (e) {
      console.error(e);
      setPhase('idle');
    }
  };

  const getStatusColor = (score: number) => {
    if (score >= 90) return "text-emerald-400";
    if (score >= 70) return "text-primary";
    if (score >= 50) return "text-yellow-400";
    return "text-red-400";
  };

  const getStatusLabel = (score: number) => {
    if (score >= 90) return "Excellent";
    if (score >= 70) return "Good";
    if (score >= 50) return "Average";
    return "Poor";
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans relative overflow-hidden selection:bg-primary/30">
      
      {/* Background Effect */}
      <div 
        className="absolute inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background z-0 pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/10 rounded-lg border border-primary/20">
            <Wifi className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold font-heading tracking-tight">Kancey<span className="text-primary">Fastspeed</span></h1>
        </div>
        <div className="flex gap-4">
           {/* Future: Settings, History */}
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 container mx-auto px-4 py-12 flex flex-col items-center justify-center min-h-[80vh]">
        
        <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column: Gauge & Main Action */}
          <div className="flex flex-col items-center justify-center space-y-12">
            <div className="relative">
              {/* Decorative Rings */}
              <div className="absolute inset-0 bg-primary/10 blur-[120px] rounded-full" />
              
              <SpeedGauge 
                value={currentSpeed} 
                max={200} // Dynamic max based on tier?
                label={phase === 'idle' || phase === 'complete' ? 'Ready' : phase === 'download' ? 'Downloading...' : phase === 'upload' ? 'Uploading...' : 'Pinging...'}
                isActive={phase !== 'idle' && phase !== 'complete'}
              />
            </div>

            <div className="flex justify-center">
              {phase === 'idle' || phase === 'complete' ? (
                <Button 
                  size="lg" 
                  onClick={startTest}
                  className="h-16 px-12 rounded-full text-lg font-bold font-heading bg-primary text-primary-foreground hover:bg-primary/90 hover:scale-105 transition-all shadow-[0_0_30px_rgba(255,193,7,0.3)] border-2 border-white/10"
                >
                  {phase === 'complete' ? (
                    <>
                      <RotateCcw className="mr-2 w-5 h-5" /> Retest
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 w-5 h-5" /> Start Test
                    </>
                  )}
                </Button>
              ) : (
                <div className="h-16 flex items-center justify-center">
                   <span className="text-muted-foreground animate-pulse font-mono uppercase tracking-widest text-sm">Testing Network...</span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Stats Grid */}
          <div className="flex flex-col gap-6 w-full">
            {/* Score Card (Only on complete) */}
            <AnimatePresence>
              {phase === 'complete' && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-6 rounded-2xl glass-card border-primary/20 bg-primary/5 mb-4"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Network Score</h3>
                      <div className={`text-4xl font-bold font-heading mt-1 ${getStatusColor(result.score)}`}>
                        {getStatusLabel(result.score)}
                      </div>
                    </div>
                    <div className="relative w-24 h-24 flex items-center justify-center">
                       <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                         <circle cx="50" cy="50" r="45" stroke="currentColor" className="text-muted/20" strokeWidth="8" fill="none" />
                         <circle cx="50" cy="50" r="45" stroke="currentColor" className={getStatusColor(result.score)} strokeWidth="8" fill="none" 
                           strokeDasharray={2 * Math.PI * 45}
                           strokeDashoffset={2 * Math.PI * 45 * (1 - result.score / 100)}
                         />
                       </svg>
                       <span className="absolute text-xl font-bold">{result.score}</span>
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
                    Your connection is stable and suitable for {result.score > 80 ? "4K streaming, competitive gaming, and large file transfers." : result.score > 50 ? "HD streaming and video calls." : "basic browsing and email."}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-2 gap-4">
              <StatCard 
                label="Download" 
                value={phase === 'download' ? currentSpeed.toFixed(1) : result.download.toFixed(1)} 
                unit="Mbps" 
                icon="download" 
                active={phase === 'download'}
              />
              <StatCard 
                label="Upload" 
                value={phase === 'upload' ? currentSpeed.toFixed(1) : result.upload.toFixed(1)} 
                unit="Mbps" 
                icon="upload" 
                active={phase === 'upload'}
              />
              <StatCard 
                label="Ping" 
                value={result.ping.toFixed(0)} 
                unit="ms" 
                icon="ping" 
                active={phase === 'ping'}
              />
              <StatCard 
                label="Jitter" 
                value={result.jitter.toFixed(0)} 
                unit="ms" 
                icon="jitter" 
                active={phase === 'ping'}
              />
            </div>
            
            {/* History Link / Footer */}
            <div className="mt-8 text-center">
              <p className="text-xs text-muted-foreground">
                Server: <span className="text-foreground">Kancey Tech Inc</span> • Protocol: <span className="text-foreground">IPv4/HTTPS</span>
              </p>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
